The converted png icons you choose for the --set-icons option will be saved to this folder.
