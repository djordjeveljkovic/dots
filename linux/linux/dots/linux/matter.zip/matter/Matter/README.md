Based on Vimix by Vince Liuice

https://www.gnu.org/software/grub/manual/grub/html_node/Theme-file-format.html
